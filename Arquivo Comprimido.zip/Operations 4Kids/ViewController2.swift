//
//  ViewController2.swift
//  Operations 4Kids
//
//  Created by Treinamento on 19/05/18.
//  Copyright © 2018 Treinamento. All rights reserved.
//

import UIKit

class ViewController2: UITableViewController {

    var operacoes: [String] = []
    var explica: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        operacoes.append("Adição")
        operacoes.append("Subtração")
        operacoes.append("Multiplicação")
        operacoes.append("Divisão")
        
        explica.append("O usuário deverá informar dois números quaisquer e como resultado aparecerá a soma dos mesmos")
        explica.append("O usuário deverá informar dois números quaisquer e como resultado aparecerá a subtração dos mesmos")
        explica.append("O usuário deverá informar dois números quaisquer e como resultado aparecerá a multiplicação dos mesmos")
        explica.append("O usuário deverá informar dois números quaisquer e como resultado aparecerá a divisão dos mesmos")
        
        
    }
    
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return operacoes.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let celulaReuso = "celulaReuso"
        let celula = tableView.dequeueReusableCell(withIdentifier: celulaReuso, for: indexPath)
        celula.textLabel?.text = operacoes[indexPath.row]
        
        return celula
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        let alertaController = UIAlertController(title: "Explicando as Operações", message: explica[indexPath.row], preferredStyle: .alert)
        let acaoConfirmar = UIAlertAction(title: "ok", style: .default, handler:nil )
        alertaController.addAction(acaoConfirmar)
        
        present(alertaController, animated: true, completion: nil)
        
        //print(explica[indexPath.row])
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
