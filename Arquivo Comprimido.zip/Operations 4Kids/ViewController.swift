//
//  ViewController.swift
//  Operations 4Kids
//
//  Created by Treinamento on 19/05/18.
//  Copyright © 2018 Treinamento. All rights reserved.
//

import UIKit

class ViewController: UIViewController{
    
    //para soma
    @IBOutlet weak var primeiroValor: UITextField!
    @IBOutlet weak var segundoValor: UITextField!
    @IBOutlet weak var resultadoSoma: UILabel!
    
    @IBAction func calcularSoma(_ sender: Any) {
        
        var primeiro: Double = 0
        var segundo: Double = 0
        var resultado: Double = 0
        
        
        if let primeirova = primeiroValor.text {
            if primeirova != ""{
                if let primeironumero  = Double (primeirova){
                    primeiro = primeironumero
                }
                
            }
            
        }
        
        if let segundova = segundoValor.text {
            if segundova != ""{
                if let segundonumero  = Double (segundova){
                    segundo = segundonumero
                }
                
            }
            
        }
        
        resultado = primeiro + segundo
        resultadoSoma.text = String(resultado)
        
    }
    
    
    //para subtracao
    
    @IBOutlet weak var primeiroSub: UITextField!
    @IBOutlet weak var segundoSub: UITextField!
    @IBOutlet weak var resultadoSub: UILabel!
    
    @IBAction func calcularSub(_ sender: Any) {
        var primeiro: Double = 0
        var segundo: Double = 0
        var resultado: Double = 0
        
        
        if let primeirova = primeiroSub.text {
            if primeirova != ""{
                if let primeironumero  = Double (primeirova){
                    primeiro = primeironumero
                }
                
            }
            
        }
        
        if let segundova = segundoSub.text {
            if segundova != ""{
                if let segundonumero  = Double (segundova){
                    segundo = segundonumero
                }
                
            }
            
        }
        
        resultado = primeiro - segundo
        resultadoSub.text = String(resultado)
    }
    
    
    //para multiplicacao
    
    @IBOutlet weak var primeiroMult: UITextField!
    @IBOutlet weak var segundoMult: UITextField!
    @IBOutlet weak var resultadoMult: UILabel!
    
    
    @IBAction func calcularMult(_ sender: Any) {
        var primeiro: Double = 0
        var segundo: Double = 0
        var resultado: Double = 0
        
        
        if let primeirova = primeiroMult.text {
            if primeirova != ""{
                if let primeironumero  = Double (primeirova){
                    primeiro = primeironumero
                }
                
            }
            
        }
        
        if let segundova = segundoMult.text {
            if segundova != ""{
                if let segundonumero  = Double (segundova){
                    segundo = segundonumero
                }
                
            }
            
        }
        
        resultado = primeiro * segundo
        resultadoMult.text = String(resultado)
        
    }
    
    
    //para divisao
    
    @IBOutlet weak var primeiroDiv: UITextField!
    @IBOutlet weak var segundoDiv: UITextField!
    @IBOutlet weak var resultadoDiv: UILabel!
    
    
    @IBAction func calcularDiv(_ sender: Any) {
        var primeiro: Double = 0
        var segundo: Double = 0
        var resultado: Double = 0
        
        
        if let primeirova = primeiroDiv.text {
            if primeirova != ""{
                if let primeironumero  = Double (primeirova){
                    primeiro = primeironumero
                }
                
            }
            
        }
        
        if let segundova = segundoDiv.text {
            if segundova != ""{
                if let segundonumero  = Double (segundova){
                    segundo = segundonumero
                }
                
            }
            
        }
        
        if segundo == 0 {
            
            resultadoDiv.text = "Não é possível fazer divisão com 0."
            
        }else{
            resultado = primeiro / segundo
            resultadoDiv.text = String(resultado)
        }
        
        
        
        
        
    }
    
    
    
    
    
 
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    


}

