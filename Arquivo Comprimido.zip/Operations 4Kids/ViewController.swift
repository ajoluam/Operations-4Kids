//
//  ViewController.swift
//  Operations 4Kids
//
//  Created by Treinamento on 19/05/18.
//  Copyright © 2018 Treinamento. All rights reserved.
//

import UIKit

class ViewController: UIViewController{
//Para Soma
    @IBOutlet weak var primeiroValorSoma: UITextField!
    @IBOutlet weak var segundoValorSoma: UITextField!
    @IBOutlet weak var resultadoSoma: UILabel!
    
    @IBAction func btnSoma(_ sender: Any) {
        var valor1: Int = 0
        var valor2: Int = 0
        var resultado: Int = 0
        //Validacoes
        if let primvar = primeiroValorSoma.text{
            if primvar != ""{
                if let primeiro = Int (primvar){
                    valor1 = primeiro
                }
            }
        }
        if let segunvar = segundoValorSoma.text{
            if segunvar != ""{
                if let segundo = Int (segunvar){
                    valor2 = segundo
                }
            }
        }
        resultado = valor1 + valor2
        resultadoSoma.text = String (resultado)
    }
    
    //Para  Subtracao
    @IBOutlet weak var primeiroValorSub: UITextField!
    @IBOutlet weak var segundoValorSub: UITextField!
    @IBOutlet weak var resultadoSub: UILabel!
    
    @IBAction func btnSub(_ sender: Any) {
        var valor1: Int = 0
        var valor2: Int = 0
        var resultado: Int = 0
        //Validacoes
        if let primvar = primeiroValorSub.text{
            if primvar != ""{
                if let primeiro = Int (primvar){
                    valor1 = primeiro
                }
            }
        }
        if let segunvar = segundoValorSub.text{
            if segunvar != ""{
                if let segundo = Int (segunvar){
                    valor2 = segundo
                }
            }
        }
        resultado = valor1 - valor2
        resultadoSub.text = String (resultado)
        
    }
    
    
    //Para Multiplicacao
    @IBOutlet weak var primeiroValorMult: UITextField!
    @IBOutlet weak var segundoValorMult: UITextField!
    @IBOutlet weak var resultadoMult: UILabel!
    
    @IBAction func btnMult(_ sender: Any) {
        var valor1: Int = 0
        var valor2: Int = 0
        var resultado: Int = 0
        //Validacoes
        if let primvar = primeiroValorMult.text{
            if primvar != ""{
                if let primeiro = Int (primvar){
                    valor1 = primeiro
                }
            }
        }
        if let segunvar = segundoValorMult.text{
            if segunvar != ""{
                if let segundo = Int (segunvar){
                    valor2 = segundo
                }
            }
        }
        resultado = valor1 * valor2
        resultadoMult.text = String (resultado)
        
        
    }
    
    //Para Divisao
    @IBOutlet weak var primeiroValorDiv: UITextField!
    @IBOutlet weak var segundoValorDiv: UITextField!
    @IBOutlet weak var resultadoDiv: UILabel!
    
    @IBAction func btnDiv(_ sender: Any) {
        var valor1: Int = 0
        var valor2: Int = 0
        var resultado: Int = 0
        //Validacoes
        if let primvar = primeiroValorDiv.text{
            if primvar != ""{
                if let primeiro = Int (primvar){
                    valor1 = primeiro
                }
            }
        }
        if let segunvar = segundoValorDiv.text{
            if segunvar != ""{
                if let segundo = Int (segunvar){
                    valor2 = segundo
                }
            }
        }
        
        if valor2 == 0 {
            resultadoDiv.text = "Não existe divisão por 0"
        }else{
            resultado = valor1 / valor2
            resultadoDiv.text = String (resultado)
            
        }
        
        
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        view.endEditing(true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    
    

}

